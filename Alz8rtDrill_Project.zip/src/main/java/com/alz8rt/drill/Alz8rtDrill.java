package com.alz8rt.drill;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.Listener;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class Alz8rtDrill extends JavaPlugin implements Listener {

    public static NamespacedKey key;

    @Override
    public void onEnable() {
        key = new NamespacedKey(this, "alz8rt_drill");
        Bukkit.getPluginManager().registerEvents(this, this);

        getCommand("alzdrill").setExecutor((sender, command, label, args) -> {
            if (!sender.hasPermission("alzdrill.give")) {
                sender.sendMessage(ChatColor.RED + "You don't have permission.");
                return true;
            }

            if (args.length != 2 || !args[0].equalsIgnoreCase("give")) {
                sender.sendMessage(ChatColor.RED + "Usage: /alzdrill give <player>");
                return true;
            }

            var target = Bukkit.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Player not found!");
                return true;
            }

            ItemStack pick = createDrill();
            target.getInventory().addItem(pick);

            sender.sendMessage(ChatColor.GREEN + "Given Alz8rt Drill to " + target.getName());
            return true;
        });
    }

    private ItemStack createDrill() {
        ItemStack pickaxe = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta meta = pickaxe.getItemMeta();

        meta.setDisplayName(ChatColor.RED + "Alz8rt Drill");
        meta.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, 1);
        meta.setUnbreakable(true);
        meta.addEnchant(Enchantment.DIG_SPEED, 5, true);

        pickaxe.setItemMeta(meta);
        return pickaxe;
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        ItemStack item = e.getPlayer().getInventory().getItemInMainHand();
        if (!isDrill(item)) return;

        var block = e.getBlock();
        var face = e.getPlayer().getFacing();

        int[][] offsets;

        switch (face) {
            case NORTH, SOUTH -> offsets = new int[][] {
                    {-1, 1, 0}, {0, 1, 0}, {1, 1, 0},
                    {-1, 0, 0}, {0, 0, 0}, {1, 0, 0},
                    {-1, -1, 0}, {0, -1, 0}, {1, -1, 0}
            };
            case EAST, WEST -> offsets = new int[][] {
                    {0, 1, -1}, {0, 1, 0}, {0, 1, 1},
                    {0, 0, -1}, {0, 0, 0}, {0, 0, 1},
                    {0, -1, -1}, {0, -1, 0}, {0, -1, 1}
            };
            case UP, DOWN -> offsets = new int[][] {
                    {-1, 0, -1}, {0, 0, -1}, {1, 0, -1},
                    {-1, 0, 0}, {0, 0, 0}, {1, 0, 0},
                    {-1, 0, 1}, {0, 0, 1}, {1, 0, 1}
            };
            default -> offsets = new int[0][0];
        }

        for (int[] o : offsets) {
            var b = block.getRelative(o[0], o[1], o[2]);
            if (!b.equals(block)) b.breakNaturally(item);
        }
    }

    private boolean isDrill(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        var meta = item.getItemMeta();
        return meta.getPersistentDataContainer().has(key, PersistentDataType.INTEGER);
    }
}
